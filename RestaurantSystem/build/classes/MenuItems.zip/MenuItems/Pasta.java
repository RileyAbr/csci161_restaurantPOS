/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MenuItems;

/**
 *
 * @author riley.abrahamson
 */
public class Pasta extends Entre {
    private String meat;
    
    public Pasta(String name, double price, int prepTime, String sides, String sauces, String meat){
        this.meat = meat;
    }
}
